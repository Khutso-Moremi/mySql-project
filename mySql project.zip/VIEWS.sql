-- Author: Fortunate Moremi 
-- 28/08/2025
-- VIEWS
-- View the status of the student.
USE eduvos_1;
CREATE OR REPLACE VIEW vw_status_1 AS
SELECT 
    s.student_id,
    s.first_name,
    s.last_name,
    e.module_id,
    CASE 
        WHEN e.mark >= 80 THEN 'Distinction'
        WHEN e.mark >= 50 THEN 'Pass'
        ELSE 'Fail'
    END AS status
FROM student_1 s
JOIN exam_1 e ON s.student_id = e.student_id;

--  View average marks by City 
USE eduvos_1;
CREATE OR REPLACE VIEW vw_avg_marks_by_city_1 AS
SELECT 
    s.city,
    AVG(e.mark) AS avg_mark
FROM student_1 s
JOIN exam_1 e ON s.student_id = e.student_id
GROUP BY s.city; 

-- View the statut of a student 
SELECT * FROM vw_status_1;

-- View average marks based on the city location
SELECT * FROM vw_avg_marks_by_city_1;