-- Author: Fortunate Moremi 
-- 28/08/2025
-- Trigger: After Insert on Exam 
-- Log Top Performers
USE eduvos_1;
DROP TRIGGER IF EXISTS trg_exam_after_insert_1;
DELIMITER $$
CREATE TRIGGER trg_exam_after_insert_1
AFTER INSERT ON exam_1
FOR EACH ROW
BEGIN
    IF NEW.mark > 90 THEN
        INSERT INTO top_performers_1 (exam_id, student_id, module_id, mark)
        VALUES (NEW.exam_id, NEW.student_id, NEW.module_id, NEW.mark);
    END IF;
END$$
DELIMITER ; 

-- After insert trigger for the top_perfromer
INSERT INTO exam_1 (student_id, module_id, exam_date, mark)
VALUES (2, 2, CURDATE(), 95.00);

-- Verify top performers log
SELECT * FROM top_performers_1;

--  BEFORE UPDATE TRIGGER (Audit old vs new marks)
-- First, update an exam mark
UPDATE exam_1 SET mark = 99 WHERE exam_id = 1;

-- Verify audit log
SELECT * FROM exam_audit_1;