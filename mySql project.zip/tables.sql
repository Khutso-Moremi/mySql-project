-- Author: Fortunate Moremi 
-- 28/08/2025
-- Database for eduvos
-- Creation of the eduvus database
CREATE DATABASE eduvos_1;
USE eduvos_1;

-- Create student table
CREATE TABLE student (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name  VARCHAR(50) NOT NULL,
    dob DATE NOT NULL,
    city VARCHAR(50) NOT NULL,
    CHECK (CHAR_lENGTH(first_name) > 0 AND CHAR_LENGTH(last_name) > 0)
);

-- Rename student table
RENAME TABLE student TO student_1;

-- Create table for module
CREATE TABLE module_1 (
    module_id INT AUTO_INCREMENT PRIMARY KEY,
    module_name VARCHAR(100) NOT NULL,
    credits INT NOT NULL CHECK (credits > 0)
);

-- Create table for exam
CREATE TABLE exam_1 (
    exam_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    module_id INT NOT NULL,
    exam_date DATE NOT NULL,
    mark DECIMAL(5,2) NOT NULL CHECK (mark >= 0 AND mark <= 100),
    FOREIGN KEY (student_id) REFERENCES student_1(student_id),
    FOREIGN KEY (module_id) REFERENCES module_1(module_id)
);

-- Create table for Module_Stats
CREATE TABLE module_stats_1 (
    stats_id INT AUTO_INCREMENT PRIMARY KEY,
    module_id INT NOT NULL,
    total_attempts INT DEFAULT 0,
    distinctions INT DEFAULT 0,
    fails INT DEFAULT 0,
    FOREIGN KEY (module_id) REFERENCES module_1(module_id)
);

-- Create table for exam audit
CREATE TABLE exam_audit_1 (
    audit_id INT AUTO_INCREMENT PRIMARY KEY,
    exam_id INT NOT NULL,
    action_type ENUM ('INSERT', 'UPDATE','DELETE'),
    old_mark DECIMAL(5,2),
    new_mark DECIMAL(5,2),
    change_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (exam_id) REFERENCES exam_1(exam_id)
);

-- Create table for top_performer
CREATE TABLE top_performers_1 (
    performer_id INT AUTO_INCREMENT PRIMARY KEY,
    exam_id INT NOT NULL,
    student_id INT NOT NULL,
    module_id INT NOT NULL,
    mark DECIMAL(5,2) NOT NULL,
    CHECK (mark >=75),
    recorded_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (exam_id) REFERENCES exam_1(exam_id),
    FOREIGN KEY (student_id) REFERENCES student_1(student_id),
    FOREIGN KEY (module_id) REFERENCES module_1(module_id)
);

-- Insert sample data for students
INSERT INTO student_1 (first_name, last_name, dob, city)
 VALUES
('Kevin', 'Phillip', '2001-08-23', 'Cape-Town'),
('Jack', 'Zuma', '1998-09-22', 'Polokwane'),
('Fortunate', 'Moremi', '1999-03-16', 'Johannesburg'),
('Edmond', 'Malepane', '1996-05-19', 'Polokwane'),
('Maputla', 'Seboko', '1999-03-26', 'Johannesburg');

-- Insert sample data for module
INSERT INTO module_1 (module_name, credits) VALUES
('Database  Management MySQL', 16),
('Programming Fundamentals', 21),
('Statistics for Data Science', 23),
('Mathematics', 24),
('Mobile app Development', 25),
('Linux', 26)
;

-- Insert sample data for exam
INSERT INTO exam_1 (student_id, module_id, exam_date, mark) 
VALUES
(1, 1, '2025-05-16', 89.00),
(1, 2, '2025-04-16', 88.00),
(1, 5, '2025-03-16', 50.00),
(2, 1, '2025-05-16', 45.00),
(2, 3, '2025-03-06', 92.00),
(3, 6, '2025-03-17', 94.00),
(3, 2, '2025-04-16', 81.00),
(3, 4, '2025-04-06', 77.00),
(4, 3, '2025-03-06', 55.00),
(4, 5, '2025-03-16', 91.00),
(4, 2, '2025-04-06', 67.00),
(5, 5, '2025-03-16', 49.00),
(5, 6, '2025-03-17', 89.00)
;
-- check student data
SELECT * FROM student_1;

-- Check modules data 
SELECT * FROM module_1;

-- Check initial exams data
SELECT * FROM exam_1;

