-- Author: Fortunate Moremi 
-- 28/08/2025
-- STORED PROCEDURES AND FUNTIONS
-- Procedure for Populate Module Stats
USE eduvos_1;
DROP PROCEDURE IF EXISTS sp_Populate_Module_Stats;
DELIMITER $$
CREATE PROCEDURE sp_Populate_Module_Stats()
BEGIN
    DELETE FROM module_stats_1 WHERE stats_id > 0;

    INSERT INTO module_stats_1 (module_id, total_attempts, distinctions, fails)
    SELECT 
        e.module_id,
        COUNT(e.exam_id) AS total_attempts,
        SUM(CASE WHEN e.mark >= 80 THEN 1 ELSE 0 END) AS distinctions,
        SUM(CASE WHEN e.mark < 50 THEN 1 ELSE 0 END) AS fails
    FROM exam_1 e
    GROUP BY e.module_id;
END$$
DELIMITER ;

-- Testing the procedure
CALL sp_Populate_Module_Stats();
SELECT * FROM module_stats_1;

-- Stored procedure for Exam_stats
USE eduvos_1;
DROP PROCEDURE IF EXISTS sp_Exam_Stats;
DELIMITER $$
CREATE PROCEDURE sp_Exam_Stats()
BEGIN
    SELECT 
        SUM(CASE WHEN mark >= 50 THEN 1 ELSE 0 END) AS passes,
        SUM(CASE WHEN mark < 50 THEN 1 ELSE 0 END) AS fails,
        SUM(CASE WHEN mark >= 80 THEN 1 ELSE 0 END) AS distinctions
    FROM exam_1;
END$$
DELIMITER ;

-- Procedure for Exam with Validation
USE eduvos_1;
DROP PROCEDURE IF EXISTS sp_Insert_Exam_With_Validation;
DELIMITER $$
CREATE PROCEDURE sp_Insert_Exam_With_Validation(
    IN p_student_id INT,
    IN p_module_id INT,
    IN p_exam_date DATE,
    IN p_mark DECIMAL(5,2)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
    END;

    START TRANSACTION;

    IF EXISTS (SELECT 1 FROM enrolment_1 
               WHERE student_id = p_student_id AND module_id = p_module_id) THEN
        INSERT INTO exam_1 (student_id, module_id, exam_date, mark)
        VALUES (p_student_id, p_module_id, p_exam_date, p_mark);
        COMMIT;
    ELSE
        ROLLBACK;
    END IF;
END$$
DELIMITER ;

-- Procedure for distinction per Module
USE eduvos_1;
DROP PROCEDURE IF EXISTS sp_Distinctions_Per_Module;
DELIMITER $$
CREATE PROCEDURE sp_Distinctions_Per_Module()
BEGIN
    SELECT 
        m.module_name,
        COUNT(e.exam_id) AS distinctions
    FROM module_1 m
    LEFT JOIN exam_1 e 
        ON m.module_id = e.module_id 
       AND e.mark >= 80
    GROUP BY m.module_id, m.module_name;
END$$
DELIMITER ;

-- FUNCTIONS

-- Top Student in Last 30 Days
USE eduvos_1;
DROP FUNCTION IF EXISTS fn_Top_Student_Last30Days;
DELIMITER $$
CREATE FUNCTION fn_Top_Student_Last30Days()
RETURNS VARCHAR(200)
DETERMINISTIC
BEGIN
    DECLARE v_name VARCHAR(200);

    SELECT CONCAT(s.first_name, ' ', s.last_name)
    INTO v_name
    FROM exam_1 e
    JOIN student_1 s ON e.student_id = s.student_id
    WHERE e.exam_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
    GROUP BY e.student_id
    ORDER BY AVG(e.mark) DESC
    LIMIT 1;

    RETURN v_name;
END$$
DELIMITER ;

-- Populate Module Stats
CALL sp_Populate_Module_Stats();
SELECT * FROM module_stats_1;

-- Exam Stats (summary of performance)
CALL sp_Exam_Stats();

--  Insert Exam with Validation
-- ✅ Case: student is enrolled → should insert
CALL sp_Insert_Exam_With_Validation(1, 1, '2025-04-01', 72.50);

--  Case: student not enrolled → should rollback
CALL sp_Insert_Exam_With_Validation(3, 3, '2025-04-01', 65.00);

-- Verify exam results
SELECT * FROM exam_1;

-- Distinctions received per module
CALL sp_Distinctions_Per_Module();

-- Top student in the last 30 days (NULL if no recent exams)
SELECT fn_Top_Student_Last30Days() AS top_student;